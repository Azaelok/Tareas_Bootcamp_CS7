import boto3
import boto3
import streamlit as st 

from langchain_chroma import Chroma
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)

from constants import (
    PERSIST_DB,
    CHROMA_SETTINGS,
    EMBEDDING_MODEL_NAME
)

from langchain_community.llms import Bedrock
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA

bedrock_client = boto3.client(service_name="bedrock-runtime")

def get_llm():
    llm=Bedrock(

        # Modelo Mistral Large (Idiomas: Inglés, francés, italiano, alemán y español)
        # --------------------------------------------------
        # model_id="mistral.mistral-large-2402-v1:0",
        # Solicitud de la API
        # --------------------------------------------------
        #{
        # "modelId": "mistral.mistral-large-2402-v1:0",
        # "contentType": "application/json",
        # "accept": "application/json",
        # "body": "{\"prompt\":\"<s>[INST] this is where you place your input text [/INST]\", \"max_tokens\":200, \"temperature\":0.5, \"top_p\":0.9, \"top_k\":50}"
        #}
        model_id="mistral.mistral-large-2402-v1:0",
        client=bedrock_client,
        model_kwargs={
            'max_tokens': 1200,  # Define la longitud máxima de la respuesta.
            'temperature': 0.5, # Este parámetro controla la capacidad creativa de su modelo.
            'top_p': 0.5,       # El parámetro top-p donde el modelo selecciona al azar entre los tokens de mayor probabilidad cuyas probabilidades suman o superan el valor top-p
            'top_k': 50,        # Top-k le dice al modelo que debe conservar los k tokens de mayor probabilidad, de los cuales se selecciona al azar el siguiente token.
            })

    return llm

def get_response(llm, vectorstore, question ):

    prompt_template = """
    Eres un asistente de IA para la empresa Green Talent. 
    Tu misión es ayudar a los analistas de seguridad informatica indicandoles los comportamientos 
    de las muestras de malware que generalmente se identifican con un hash sha56, 
    para lograr esto apoyate de la base de conocimiento de MITRE ATT&CK, MBC Behavior y las habilidades 
    o capacidades maliciosas, así que utiliza los siguientes fragmentos de contexto para responder a la pregunta.

    <context>
    {context}
    </context>

    Question: {question}

    Assistant:"""

    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )

    qa = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=vectorstore,
    return_source_documents=True,
    chain_type_kwargs={"prompt": PROMPT}
    )
    answer=qa({"query":question})
    #print("answer: ", answer)
    
    return answer['result']


def main():

    st.title("Green Talent")
    st.divider()
    st.header("CAPE + CAPA + Python + RAG + ChromaDB + LangChain + AWS Bedrock + Mistral + Streamlit")

    embedding_function = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    #print("embedding_function: ",embedding_function)
    
    db = Chroma(persist_directory=PERSIST_DB, embedding_function=embedding_function)

    retriever = db.as_retriever()
    #print("retriever: ",retriever)

    question = st.text_area("Ingresa tu prompt:")
    print("question", question)

    docs = db.similarity_search(question)

    print("")
    print("page content",docs[0].page_content)
    print("")

    if st.button(" Enviar "):
        with st.spinner("Consultando..."):

            llm = get_llm()

            st.write(get_response(llm, retriever, question))
            st.success("Respuesta entregada.")

if __name__ == "__main__":
    main()
