
# La libreria de streamlit se instala con pip3
pip3 install streamlit

# Ejecucion de la app
python -m streamlit run app.py
