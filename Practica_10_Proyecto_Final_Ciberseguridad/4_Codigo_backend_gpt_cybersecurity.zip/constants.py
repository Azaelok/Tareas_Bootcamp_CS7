import os

from chromadb.config import Settings

from langchain_community.document_loaders import CSVLoader, PDFMinerLoader, TextLoader, UnstructuredExcelLoader, Docx2txtLoader
from langchain_community.document_loaders import UnstructuredFileLoader, UnstructuredMarkdownLoader
from langchain_community.document_loaders import UnstructuredHTMLLoader

# Directorio Raiz Proyecto
ROOT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))

# Directorio para cargar Documentos
SOURCE_DOCUMENTS = f"{ROOT_DIRECTORY}\\SOURCE_DOCUMENTS\\"

# Ruta Guardar la BD Vectorial
PERSIST_DB = f"{ROOT_DIRECTORY}\\DB_User\\"

print("Numero de Cores",os.cpu_count())
INGEST_THREADS = os.cpu_count() or 8

# Configuracion de Chroma
CHROMA_SETTINGS = Settings(
    anonymized_telemetry=False,
    is_persistent=True,
)


CONTEXT_WINDOW_SIZE = 4096
MAX_NEW_TOKENS = CONTEXT_WINDOW_SIZE  # int(CONTEXT_WINDOW_SIZE/4)

N_GPU_LAYERS = 100 
N_BATCH = 512

# https://python.langchain.com/en/latest/_modules/langchain/document_loaders/excel.html#UnstructuredExcelLoader
DOCUMENT_MAP = {
    ".html": UnstructuredHTMLLoader,
    ".txt": TextLoader,
    ".md": UnstructuredMarkdownLoader,
    ".py": TextLoader,
    ".pdf": UnstructuredFileLoader,
    ".csv": CSVLoader,
    ".xls": UnstructuredExcelLoader,
    ".xlsx": UnstructuredExcelLoader,
    ".docx": Docx2txtLoader,
    ".doc": Docx2txtLoader,
}


# hkunlp/instructor-large: Es un modelo especializado en generar embeddings adaptados a tareas específicas (clasificación, recuperación, agrupamiento, etc.) e incluso dominios (ciencia, finanzas, etc.).
# si necesitas la máxima precisión en una tarea específica y estás dispuesto a sacrificar algo de velocidad.
EMBEDDING_MODEL_NAME = "hkunlp/instructor-large"  # Uses 1.5 GB of VRAM (High Accuracy with lower VRAM usage)

# all-MiniLM-L6-v2: Es un modelo de propósito general. Se entrena para generar representaciones vectoriales (embeddings) de oraciones y párrafos que capturan su significado semántico. 
# Se utiliza en tareas como clustering y búsqueda semántica.
# si necesitas un modelo rápido y versátil para tareas generales de procesamiento de lenguaje natural.
#EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
