import os
import uuid


from langchain_chroma import Chroma
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings.sentence_transformer import (
    SentenceTransformerEmbeddings,
)
from langchain_text_splitters import CharacterTextSplitter

from constants import (
    SOURCE_DOCUMENTS,
    PERSIST_DB,
    EMBEDDING_MODEL_NAME
)


#def list_files(directory):
#  """Lists all files in the given directory."""
#  file_paths = []
#  for filename in os.listdir(directory):
#
#    filepath = os.path.join(directory, filename)
#    if os.path.isfile(filepath):
#      #print(filename)
#      #print(filepath)
#      file_paths.append(filepath)
#  print(file_paths)


def load_documents_in_batches(documents_dir, batch_size=9):
    documents = []
    for filename in os.listdir(documents_dir):
        print(f"Cargando: {filename}")
        filepath = os.path.join(documents_dir, filename)
        documents.append(TextLoader(filepath).load())
        if len(documents) >= batch_size:
            yield documents
            documents = []
    if documents:
        yield documents

#list_files(SOURCE_DOCUMENTS)
# Load documents in batches
loader = load_documents_in_batches(SOURCE_DOCUMENTS)

i=0
all_documents = []
for document_batch in loader:
    #print(document_batch)
    docs = []
    for document in document_batch:
        text_splitter = CharacterTextSplitter(separator='\n', chunk_size=500, chunk_overlap=100)
        print("text_splitter: ",text_splitter)
        split_docs = text_splitter.split_documents(document)
        print(f"Fragmentos generados: {len(split_docs)}")
        print(f"Indice: {split_docs[i]}")
        
        docs.extend(split_docs)
        #docs.extend(text_splitter.split_documents(document))       
        i+=1
    all_documents.extend(docs)  # Collect all documents across batches

print(f"Total de documentos procesados: {len(all_documents)}")

embedding_function = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL_NAME)
#print("embedding_function: ", embedding_function)

ids=[str(uuid.uuid1())]
print("ids",ids)

#db2 = Chroma.from_documents(all_documents, embedding_function, persist_directory=PERSIST_DB)
db2 = Chroma.from_documents(
    all_documents, 
    embedding_function,
    collection_name="ejemplo",
    persist_directory=PERSIST_DB
    )

#retriever = db2.as_retriever()
#print("retriever: ", retriever)


print(db2.get().keys())
print(db2.get().keys())


query1 = "0a05eba9b38cfdd6f60eaa673a215197449cf1c71eb2fff70a99f8d68fbee089"
docs1 = db2.similarity_search(query1)
print("Impresion resultados1: ",docs1[0].page_content)

query2 = "0b7603161318f90dbac1e3ed5ffdbcfa7c1b281e29461157d7dc8d5409ac8b09"
docs2 = db2.similarity_search(query2)
print("Impresion resultados2: ",docs2[0].page_content)

query3 = "0a8baa7e1def1d17c38a9f608493a99123f74d34d0d4f8154a5649e5d3f9669b"
docs3 = db2.similarity_search(query3)
print("Impresion resultados3: ",docs3[0].page_content)

query4 = "0a54be784817dc2cb8946a67b25912ba685857f877d556b2291864125d99655f"
docs4 = db2.similarity_search(query4)
print("Impresion resultados4: ",docs4[0].page_content)

query5 = "0afa799f3b3d3bd54909bc230bc89b76958a406cddb8df5c6fb9799f73239b94"
docs5 = db2.similarity_search(query5)
print("Impresion resultados5: ",docs5[0].page_content)

query6 = "0b6e11ec83f03d4dffd348f50c3009042ecf5a66463d39c4ff87a81954aab98c"
docs6 = db2.similarity_search(query6)
print("Impresion resultados6: ",docs6[0].page_content)

query7 = "0b404d97c5e5cb94ca172ac74694740cfba8d05ed0712d9179b8e89345a029f4"
docs7 = db2.similarity_search(query7)
print("Impresion resultados7: ",docs7[0].page_content)

#query8 = "Que es nomina empresarial azteca"
#docs = db2.similarity_search(query8)
#print("Impresion resultados: ",docs[0].page_content)





#import os
#
#
#
#
## Función para procesar archivos grandes en lotes
#def process_large_files(file_paths, batch_size=100):
#    batch_docs = []
#    
#    for file_path in file_paths:
#        with open(file_path, 'r', encoding='utf-8') as f:
#            for line in f:
#                batch_docs.append(line.strip())
#                if len(batch_docs) >= batch_size:
#                    save_embeddings(batch_docs)
#                    batch_docs = []  # Reiniciar el lote
#
#    # Guardar cualquier documento restante
#    if batch_docs:
#        save_embeddings(batch_docs)
#
#
## Lista de archivos a procesar
#file_paths = ["archivo1.txt", "archivo2.txt", ...]  # Añadir tus archivos aquí
#
#process_large_files(file_paths)        