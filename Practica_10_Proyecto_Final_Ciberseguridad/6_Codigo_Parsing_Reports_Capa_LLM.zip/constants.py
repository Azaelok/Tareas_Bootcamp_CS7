import os

# Directorio Raiz Proyecto
ROOT_DIRECTORY = os.path.dirname(os.path.realpath(__file__))

SOURCE_REPORTS = f"{ROOT_DIRECTORY}\\Input_List_Reports_Capa\\"

PROCESSED_REPORTS = f"{ROOT_DIRECTORY}\\Input_List_Reports_Capa\\processed\\"

OUTPUT_REPORTS = f"{ROOT_DIRECTORY}\\Output_List_Reports_LLM\\"
