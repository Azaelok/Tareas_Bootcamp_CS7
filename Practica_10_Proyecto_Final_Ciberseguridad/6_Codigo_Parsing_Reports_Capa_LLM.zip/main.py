import os
import re
import shutil

from constants import(
    SOURCE_REPORTS,
    PROCESSED_REPORTS,
    OUTPUT_REPORTS
)

print("")
print("Inicio")
print("--------------------------------------------------")
print("")

def parsing_capa_llm(source_reports=SOURCE_REPORTS, processed_reports=PROCESSED_REPORTS, output_reports=OUTPUT_REPORTS):



    for archivo in os.listdir(source_reports):
        #print("algo ",archivo)

        path_file = source_reports+archivo

        cinicio=archivo.find("_")
        cfin=archivo.rfind(".")

        name_sha256=archivo[cinicio+1:cfin]
        print("Muestra:", name_sha256)
        print("")

        if archivo.endswith(".txt"):
            file_name = "LLM_"+archivo
            
            with open(os.path.join(source_reports, archivo), "r", encoding="utf-8") as f:
                contenido = f.read()
                #print(f"Contenido de {archivo}:")
                #print(contenido)

                # ---------------------------------------------------------------------
                # Patrón para identificar líneas de la tabla
                pattern = r"│\s*(?P<key>.*?)\s*│\s*(?P<value>.*?)\s*│"

                
                matches = re.findall(pattern, contenido)
                #print(matches)

                with open(output_reports+file_name, "w", encoding="utf-8") as f:
                    for valor in matches:
                        #print("valor {valor}")
                        section_content = valor[0].strip() + " *" +valor[1].strip()
                    
                        if valor[0].strip() == "md5":
                            #sha256 = valor[1].strip()
                            var_md5="Se ha realizado un análisis dinámico a la siguiente muestra de malware, esta misma se identifica a traves del hash SHA256: " + name_sha256 + ", esta muestra reveló diversas tácticas y técnicas del marco MITRE ATT&CK, así como sus principales capacidades maliciosas, las cuales representan un riesgo significativo para la seguridad de múltiples sistemas. La información más relevante se ha resaltado con asteriscos (*)."
                            f.writelines(var_md5+"\n")

                        if valor[0].strip() == "os":
                            var_plataforma = valor[1].strip()                            
                            plataforma="Plataforma de ejecucion del malware: " + var_plataforma
                            f.writelines("\n"+plataforma+"\n")
                        
                        if valor[0].strip() == "format":
                            var_formato = valor[1].strip()                            
                            formato="El tipo de formato es: " + var_formato
                            f.writelines("\n"+formato+"\n")

                        if valor[0].strip() == "arch":
                            var_arquitectura = valor[1].strip()
                            arquitectura="El tipo de arquitectura es: " + var_arquitectura
                            f.writelines("\n"+arquitectura+"\n")

                        if valor[0].strip() == "ATT&CK Tactic":
                            var_TacticTechnique= "Las principales tácticas y técnicas de MITRE ATT&CK asociadas a la muestra de malware con hash SHA256: " + name_sha256 + " se detallan a continuación. Estas tácticas y técnicas proporcionan una comprensión profunda del comportamiento del malware y su potencial impacto en la seguridad de los sistemas."
                            f.writelines("\n"+var_TacticTechnique+"\n")

                        if valor[0].strip() == "MBC Objective":                            
                            var_ObjectiveBehavior="El análisis de la muestra de malware con hash SHA256: "+ name_sha256 + " se ha realizado utilizando el Catálogo de Objetivos (MBC Objective) y Comportamientos de Malware (MBC Behavior). Este enfoque ha permitido identificar los siguientes comportamientos maliciosos asociados a la muestra."
                            f.writelines("\n"+var_ObjectiveBehavior+"\n")

                        if valor[0].strip() == "Capability":                            
                            var_Capability= "El análisis de la muestra de malware con hash SHA256: " + name_sha256 + " ha revelado las siguientes habilidades o capacidades maliciosas. Estas capacidades del malware representan un riesgo significativo para la seguridad de los sistemas informáticos, por lo que es crucial comprender su naturaleza y alcance."
                            f.writelines("\n"+var_Capability+"\n")

                        #print("¡Coincidencia!", valor[1].strip())
                        print(section_content)
                        f.writelines(section_content+"\n")
        shutil.move(path_file, processed_reports)


parsing_capa_llm(SOURCE_REPORTS, PROCESSED_REPORTS, OUTPUT_REPORTS)

print("")
print("Fin")
print("--------------------------------------------------")
print("")
